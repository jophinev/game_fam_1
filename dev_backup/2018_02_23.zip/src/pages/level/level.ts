import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { GamePage } from '../game/game';

import { ServiceProvider } from '../../providers/service/service';
import { UtilityProvider } from '../../providers/utility/utility';
import { AudioProvider } from '../../providers/audio/audio';


@Component({
  selector: 'page-level',
  templateUrl: 'level.html',
})
export class LevelPage {
  private isServiceInit:boolean = false;
  private levelData:Array<any> = null;

  constructor(public navCtrl: NavController, public navParams: NavParams, private sp:ServiceProvider, private up:UtilityProvider, private ap:AudioProvider) {
    this.up.showLoader();
    this.init();
  }

  ionViewDidLoad() {
    //this.up.showLoader();
  }

  ionViewDidEnter(){
  	this.up.showLoader();
    //debugger;
    //this.ap.playAudio = "Hi this is my first text to speech example"

  }

  ionViewWillLeave(){

  }

  private init(){
    this.sp.initKinveyServices().then((resp)=>{
      //this.up.hideLoader();
      this.fetchLevelData();
    }, (err)=>{
      this.up.hideLoader();
    })
  }

  private fetchLevelData(){
    this.sp.fetchLevelData({"reqType":"get","level":0}).then((resp:Array<any>)=>{
      this.sp.levelData = resp
      this.fetchImages();
    },(err)=>{

    })
  }

  private fetchImages(){
    let levelData = this.sp.levelData;
    let wordImgArr:Array<any> = [];
    let subWordImgArr:Array<any> = [];
    let wordSndArr:Array<any> = [];
    let subWordSndArr:Array<any> = [];
    for(let i:number = 0; i < levelData.length; i++){
      wordImgArr.push(this.sp.fetchImages("wordImg",levelData[i].wordImg, levelData[i].word));
      subWordImgArr.push(this.sp.fetchImages("subWordImg",levelData[i].subWordImg, levelData[i].subWord));
      wordSndArr.push(this.sp.fetchImages("wordSound",levelData[i].subWordSound, levelData[i].word));
      subWordSndArr.push(this.sp.fetchImages("subWordSound",levelData[i].subWordSound, levelData[i].subWord));
    }

    Promise.all(wordImgArr).then((resp)=>{
      this.sp.wordImgArr = resp;
    }, (err)=>{
      debugger;
    });
    Promise.all(subWordImgArr).then((resp)=>{
      debugger;
    }, (err)=>{
      debugger;
    });
    Promise.all(wordSndArr).then((resp)=>{
      debugger;
    }, (err)=>{
      debugger;
    });
    Promise.all(subWordSndArr).then((resp)=>{
      debugger;
    }, (err)=>{
      debugger;
    });
  }

}


