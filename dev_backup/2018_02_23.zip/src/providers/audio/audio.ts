import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TextToSpeech } from '@ionic-native/text-to-speech';
@Injectable()
export class AudioProvider {

	constructor(private tts: TextToSpeech) {
		console.log('Hello AudioProvider Provider');
	}

	public set playAudio(_text) {
		this.tts.speak(_text)
			.then(() => console.log('Success'))
			.catch((reason: any) => console.log(reason));
	}

}
