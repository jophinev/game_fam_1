export interface iLevel{

}

export class DataBucket implements iLevel{
	private _activeUser: Object = null;
	private _levelData:Array<Object> = null;
	private _wordImage:Array<Object> = null;

	constructor() {
		console.log('Hello DataBucket');
	}

	public get activeUser() {
		return this._activeUser;
	}

	public set activeUser(_userInfo){
		this._activeUser = _userInfo;
	}

	public get levelData() {
		return this._levelData;
	}

	public set levelData(_pData){
		this._levelData = _pData;
	}

	public get wordImage() {
		return this._wordImage;
	}

	public set wordImage(_pData){
		this._wordImage = _pData;
	}
	



}