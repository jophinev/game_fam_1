import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Kinvey } from 'kinvey-angular2-sdk';

import { DataBucket } from './dataBucket';

@Injectable()
export class ServiceProvider extends DataBucket {

	constructor(public http: HttpClient) {
		super();
		console.log('Hello ServiceProvider Provider');
	}

	public initKinveyServices() {
		return new Promise((resolve, reject) => {
			Kinvey.init({
				appKey: 'kid_rkc0iZHwf',
				appSecret: '6a2aa85690e94dc19a5901721de787ba'
			});
			if (this.activeUser) {
				resolve(this.activeUser);
			} else {
				let _actUser = Kinvey.User.getActiveUser();
				this.activeUser = _actUser.data;
				if (this.activeUser) {
					resolve(this.activeUser);
				} else {
					Kinvey.User.login("jvmbusi@gmail.com", "Farm_2018")
						.then((user: Kinvey.User) => {
							this.activeUser = user.data;
							resolve(this.activeUser);
						})
						.catch((error: Kinvey.BaseError) => {
							reject(error);
						});
				}
			}
		})
	}

	public fetchLevelData(_param) {
		//let self: any = this;
		return new Promise((resolve, reject) => {
			Kinvey.CustomEndpoint.execute("getLevelData", _param)
				.then(function(respData: any) {
					//console.log(self);
					//self.levelData = respData.data;
					resolve(respData.data);
				}).catch(function(error: any) {
					reject(error);
				});
		})
	}

	public fetchImages(fieldName, fileName, word) {
		return new Promise((resolve, reject) => {
			const query = new Kinvey.Query();
			query.equalTo("_filename", fileName);
			Kinvey.Files.find(query)
				.then((files: any) => {
					resolve({ "url": files[0]._downloadURL, "word": word });
				})
				.catch((error: Kinvey.BaseError) => {
					reject(error);
				});

			/*Kinvey.Files.download(fileName)
				.then((file: {}) => {
					resolve(file._data);
				})
				.catch((error: Kinvey.BaseError) => {
					reject(error);
				});*/
		})
	}
}
